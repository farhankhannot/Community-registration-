// Firebase Configuration (Apni details yahan dalein)
const firebaseConfig = {
    apiKey: "YOUR_API_KEY",
    authDomain: "YOUR_PROJECT.firebaseapp.com",
    projectId: "YOUR_PROJECT_ID",
    storageBucket: "YOUR_PROJECT.appspot.com",
    messagingSenderId: "YOUR_ID",
    appId: "YOUR_APP_ID"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();
const storage = firebase.storage();

const form = document.getElementById('regForm');

form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = document.getElementById('submitBtn');
    btn.innerText = "Processing...";
    btn.disabled = true;

    const file = document.getElementById('screenshot').files[0];
    const storageRef = storage.ref('screenshots/' + file.name);

    try {
        // 1. Upload Image to Firebase Storage
        const snapshot = await storageRef.put(file);
        const imgUrl = await snapshot.ref.getDownloadURL();

        // 2. Save Data to Firestore
        await db.collection("registrations").add({
            fullName: document.getElementById('fullName').value,
            whatsapp: document.getElementById('whatsapp').value,
            community: document.getElementById('community').value,
            paymentMethod: document.getElementById('paymentMethod').value,
            transactionId: document.getElementById('txId').value,
            screenshotUrl: imgUrl,
            timestamp: firebase.firestore.FieldValue.serverTimestamp()
        });

        alert("Registration Successful!");
        form.reset();
    } catch (error) {
        console.error(error);
        alert("Something went wrong. Please try again.");
    } finally {
        btn.innerText = "Submit Registration";
        btn.disabled = false;
    }
});

